EXCEL\_TAIL

HIDDEN\_SHEET\_VALUE

机型:SY215C。

部件:履带张紧装置。

故障现象:行走跑偏。

，再检查右侧履带张紧度。

张紧度。

The pressure reading is 12.5 MPa.