---
id: procedure-ac-not-cooling-inspection
title: 空调不制冷诊断流程
description: 从鼓风机是否运转、压缩机是否吸合两个分支点出发，逐步定位空调不制冷的根因。
class_name: inspection
object_name: 空调不制冷诊断流程
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
procedure_scope: composite
fault_refs:
  - viking://resources/<ns>/Fault/ControlFailure/空调控制盒内部故障.md
  - viking://resources/<ns>/Fault/MechanicalFailure/空调压缩机损坏.md
target_components:
  - viking://resources/<ns>/Component/显示屏/显示控制屏SEED-10IB-55G-大挖出口机标清.md
  - viking://resources/<ns>/Component/发动机/发动机QSL9-231kW.md
applicable_configs:
  - viking://resources/<ns>/Device/SY215/SY215C/12767364/profile.md
open_gaps: []
sources:
  - viking://resources/730/fault_mechanism/中挖-维修助手研发机理标注-第二批/空调不制冷.md
---
## 操作目的
定位「空调不制冷」根因，区分送风侧与制冷侧故障，收敛到具体失效
[原文](viking://resources/730/fault_mechanism/中挖-维修助手研发机理标注-第二批/空调不制冷.md)。
## 操作步骤
1. **步骤1 确认 A/C 请求已发出**：按下 A/C 键观察触摸屏响应。
   - 前提：点火 ON、空调面板供电正常
   - 分支：正常（屏有响应）→ 步骤3；异常（无响应）→ 步骤2
2. **步骤2 检查空调控制链路**：CAN 通信、控制盒输出、功率模块保险。
   - 测量项: `can-bus-voltage`（受控词表）
   - 判据：数值以适用 ConfigSpec 标准值表为准，本页不复制
   - 异常 → 空调控制盒内部故障
     [空调控制盒内部故障](viking://resources/<ns>/Fault/ControlFailure/空调控制盒内部故障.md)
3. **步骤3 判断鼓风机是否运转**（第一分支点）。
   - 分支：正常 → 步骤4；异常 → 空调鼓风机损坏
     [空调鼓风机损坏](viking://resources/<ns>/Fault/MechanicalFailure/空调鼓风机损坏.md)
4. **步骤4 观察压缩机是否吸合**（第二分支点）。
   - 分支：异常（吸合但异响）→ 空调压缩机损坏
5. **步骤5 测量冷媒压力**：
   - 测量项: `refrigerant-low-pressure` / `refrigerant-high-pressure`
   - 判据：以适用 ConfigSpec 标准值表为准
## 判定标准
- 任一步单点测量异常即进入对应 Fault 处置，无需跑完全部步骤；各配置档判据数值
  以对应 ConfigSpec 标准值表为准。
## 后续处理
- 定位后按对应 Fault 的修复方式处置。
- 全部正常但故障仍存在 → 挂 open_gap 上报专家复核，禁止硬猜根因。
## 来源
- 中挖-维修助手研发机理标注-第二批·空调不制冷章（frontmatter sources 全列）。

（说明：路径 Procedure/inspection/空调不制冷诊断流程.md——大类五选一；fault_refs
必填（流程挂在它验证的失效上，无锚 = 孤儿 deny）；target_components 只收 Component
（十九类大类词表页）；适用性经 ConfigSpec 派生、禁手写 applicable_models；
inspection/test 走诊断模板五节，replacement/repair/disassembly 走作业模板七节，
作业型必有「回装验证」；步骤号中文「步骤N」全页唯一；
同源 URI 全页只在**首次出现处**引一次，后续句子靠 sources 字段归源不复读。）
