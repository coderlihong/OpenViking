---
id: configspec-ssy100000402
title: SY135C — SSY100000402
description: SY135C 生产版本 SSY100000402，装 QSL9 231kW 发动机与液控多路阀 HVME700。
class_name: SY135C
object_name: SSY100000402配置档
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
host_code: SSY100000402
device_refs:
  - viking://resources/<ns>/Device/SY135/SY135C/index.md
  - viking://resources/<ns>/Device/SY135/SY135C9M2K/index.md
axes:
  emission: 国四和新欧五
  controller: 10寸触摸屏+空调控制盒
  tonnage: 13吨级
bom_composition:
  - component_uri: viking://resources/<ns>/Component/发动机/发动机QSL9-231kW.md
    spec: 发动机QSL9 231kW
  - component_uri: viking://resources/<ns>/Component/多路阀(主阀)/液控多路阀HVME700-000000-012.md
    spec: 液控多路阀HVME700-000000-012
  - component_uri: viking://resources/<ns>/Component/其他/涡轮增压器.md
    spec: 涡轮增压器
capabilities:
  - 具备CAN通信链路（仪表-控制器）
  - 具备空调系统（R134a冷媒）
open_gaps:
  - field: bom_composition.intercooler
    reason: 中冷器规格串原文未给出，定名不定故不建页（保留原串待补，禁丢弃）
sources:
  - viking://resources/730/manuals/SY135C维修手册-2024版/chapters/07/chapter.md
---
## 配置定义
SY135C 机型下 hostcode 为 SSY100000402 的生产版本（机型归属读 device_refs，路径不承载——
本页住 `ConfigSpec/SSY100000402/index.md`；机型级各码差异见被绑机型页
`Device/SY135/SY135C/index.md` 的差异对照节）。与同机型其他
hostcode 的差异点：装 QSL9 231kW 发动机、液控多路阀 HVME700-000000-012
[原文](viking://resources/730/manuals/SY135C维修手册-2024版/chapters/07/chapter.md)。
## BOM 组成
| 部件 | 规格 | 对应 Component |
|---|---|---|
| 发动机 | 发动机QSL9 231kW | [发动机QSL9-231kW](viking://resources/<ns>/Component/发动机/发动机QSL9-231kW.md) |
| 多路阀(主阀) | 液控多路阀HVME700-000000-012 | [液控多路阀HVME700](viking://resources/<ns>/Component/多路阀(主阀)/液控多路阀HVME700-000000-012.md) |
| 其他 | 涡轮增压器 | [涡轮增压器](viking://resources/<ns>/Component/其他/涡轮增压器.md) |
规格串解析不到库内 Component 时保留原串并在 open_gaps 挂账，禁丢弃。
词表外零件（增压器/EGR阀等）落「其他」缺档类建页，不因大类缺档挂 gap。
## 设计基准
A/C 请求与状态信号经 CAN 总线传输（总线电压标准值见下表）。
## 配置能力声明
- 具备 CAN 通信链路（仪表-控制器）→ 「CAN 通讯断开」类根因在本档成立（机械面板档不成立）。
## 标准值参考
### 空调系统
| 测量项(term_id) | 正常值 | 单位 | 方法 | 适用条件 | 测点位置 |
|---|---|---|---|---|---|
| aircon-low-pressure | 0.15-0.25 | MPa | 歧管压力表 | R134a冷媒·热机怠速 | 低压检修阀 |
## 来源
- SY135C维修手册-2024版·配置/空调章（frontmatter sources 全列）。

（说明：路径 ConfigSpec/SSY100000402/index.md——host_code 必须等于主体码目录段、文件名固定
index.md；subject_code 已废止出现即 deny；device_refs 是「配置档 ↔ 机型」的唯一事实源，
必填非空、元素为 Device/<系列>/<型号>/index.md，Device 侧 config_specs 是它的派生投影；
标准值表六列列序钉死，「适用条件」禁「看情况」类自由文本；根因清单/诊断顺序属 Profile，
本页出现即拒。）
