---
id: fault-walk-drift-controller-program
title: 行走跑偏-主控制器程序异常/版本错误（大挖）
description: 主控制器输出指令异常，一侧行走慢，更新程序后解除。
class_name: ControlFailure
object_name: 行走跑偏-主控制器程序异常/版本错误（大挖）
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
affected_components:
  - viking://resources/<ns>/Component/多路阀(主阀)/液控多路阀HVME700-000000-012.md
sources:
  - viking://resources/raw/textbook/行走跑偏/chapters/10.md
  - viking://resources/raw/textbook/行走跑偏/chapters/14.md
  - viking://resources/raw/textbook/行走跑偏/chapters/19.md
  - viking://resources/raw/textbook/行走跑偏/chapters/20.md
  - viking://resources/raw/textbook/行走跑偏/chapters/22.md
---
## 失效描述
主控制器程序异常/版本错误，控制器输出指令异常，一侧行走慢，更新程序后解除。
属电控链路环节的根因 [原文](viking://resources/raw/textbook/行走跑偏/chapters/10.md)。
## 失效机理
大挖电控先导机型主控制器根据输入信号计算并输出行走指令。当控制器程序异常或版本错误时，
控制器输出指令异常，一侧行走指令偏差，该侧行走慢，整机向慢侧跑偏。更新/核对控制器程序
版本后解除 [原文](viking://resources/raw/textbook/行走跑偏/chapters/14.md)。
## 配置差异化
按「根因 × 配置档（配件组合）」写，每配置档一行结论（剪除/适用 + 理由/证据；
安装机型作档内载体注记，配置↔机型关系的权威是 ConfigSpec 配置档页）：
- 华兴控制器+华昌主阀配置档（载体：SY365F/H 等）：适用。SY365 左行走跑偏，
  左行走慢致跑偏、更新程序解除（案例实证，可信度高）
  [原文](viking://resources/raw/textbook/行走跑偏/chapters/19.md)。
- 电控先导控制器配置档（载体：SY550H/650H/750H/980H）：适用（排查项）。
  增益标定、程序版本为电控链路排查项；源无该配置档下本根因的实证案例。
- 无主控制器程序环节的液压配置档（载体：低挖 SY16~95、小挖 SY135/155、
  中挖 SY195/205/215）：本根因剪除——该配件组合不含主控制器程序环节
  （出处见「失效描述」段那条 [原文]；引文节级口径：同节至多一条，跨节复引合法）；
  源未给出这些档的配件组合名，配置归属待确认（挂 gap）。
## 常见原因
- 主控制器程序异常。
- 主控制器程序版本错误。
## 影响范围
左行走慢致跑偏；影响华兴控制器+华昌主阀、电控先导控制器两配置档（载体见
「配置差异化」节）。行走指令的执行部件
[液控多路阀HVME700-000000-012](viking://resources/<ns>/Component/多路阀(主阀)/液控多路阀HVME700-000000-012.md)。
## 关联故障现象
- 行走跑偏 [行走跑偏](viking://resources/<ns>/Symptom/行走系统/行走跑偏/行走跑偏.md)
## 验证方法
读取控制器程序版本与官方发布版本核对，版本不符即确认本机理
[主控制器程序版本检查](viking://resources/<ns>/Procedure/inspection/主控制器程序版本检查.md)
## 修复方式
重写控制器程序后试机，跑偏消除即修复完成
[主控制器程序更新](viking://resources/<ns>/Procedure/repair/主控制器程序更新.md)

（说明：路径 Fault/ControlFailure/行走跑偏-主控制器程序异常.md——失效类七选一；
「验证方法/修复方式」的 `[<规程名>](<完整Procedure URI>)` 是 Procedure.fault_refs 的扇入投影，
Fault 页没有 Procedure 字段；affected_components 与「影响范围」成对（双载体），
Fault.affected_components 是唯一部件关系；Component 不保存 related_faults 反向清单。正文禁线号/测量值。）
