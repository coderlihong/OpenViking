---
id: dtc-e828-vcu-7f2a1c
title: E828_VCU液压油温过温
description: VCU 检测液压油温过热触发的热管理报警。
class_name: SY35E_SSY100000823
object_name: E828_VCU液压油温过温
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
code: E828
machine_model: SY35E
controller_role: VCU
fault_level: 1
related_symptoms:
  - viking://resources/<ns>/Symptom/整机/液压油温高/液压油温高.md
related_faults:
  - viking://resources/<ns>/Fault/ThermalFailure/VCU液压油温过温E828.md
sources:
  - kb://chapters/813927429744789
---
## 代码定义
VCU 检测液压油温超阈值时触发 E828 报警，机器同时开启电子风扇至高速并在显示屏
弹热管理故障图标 [原文](kb://chapters/813927429744789)。
## 设备表现
热管理报警图标亮起，风扇全速运转；动作不限。
## 排查步骤
查其他故障码 → 查风扇 → 查控制器采集油温（瞬变异常则查油温传感器/多合一低压插头）
→ 清洗散热器（出处见「代码定义」段那条 [原文]；同节不再重复挂链接）。
## 可能失效机理
风扇故障 / 油温传感器异常 / 散热器堵塞。机理展开见关联 Fault 页
[VCU液压油温过温E828](viking://resources/<ns>/Fault/ThermalFailure/VCU液压油温过温E828.md)。

（说明：路径 DTC/SY35E_SSY100000823/E828.md——目录段 = <机型>_<hostcode>，
文件名逐字是代码、译名只进 title；身份 = 机型+hostcode+代码全库唯一（控制器角色是属性字段），
译名差异 PATCH 既有页记 alias；related_symptoms/related_faults 双缺且无
[open_gap:] = 孤岛 deny；仅占故障代码表一行的码不建页，由 Device「故障代码清单」承载。）
