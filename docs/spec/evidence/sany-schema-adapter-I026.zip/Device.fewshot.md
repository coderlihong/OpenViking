---
id: device-sy135c
title: SY135C
description: 三一SY系列13吨级小挖，机型索引页：下辖 hostcode 差异对照与配置档引用。
class_name: 小挖/SY135系列
object_name: SY135C
status: active
series: SY135
model: SY135C
publication_state: published
validation_state: machine_validated
review_state: unreviewed
config_specs:
  - viking://resources/<ns>/ConfigSpec/SSY100000402/index.md
raw_refs:
  - viking://resources/730/manuals/SY135C维修手册-2024版/chapters/00/chapter.md
  - viking://resources/730/manuals/SY135C维修手册-2024版/chapters/07/chapter.md
current_manual: viking://resources/730/manuals/SY135C维修手册-2024版/chapters/00/chapter.md
critical_components:
  - viking://resources/<ns>/Component/发动机/发动机QSL9-231kW.md
  - viking://resources/<ns>/Component/多路阀(主阀)/液控多路阀HVME700-000000-012.md
symptom_refs:
  - viking://resources/<ns>/Symptom/动力与发动机/发动机冒白烟/发动机冒白烟.md
---
## 机型介绍
三一SY系列13吨级小挖。供油方式覆盖机械发动机与电控发动机（高压共轨+EGR）
[原文](viking://resources/730/manuals/SY135C维修手册-2024版/chapters/00/chapter.md)。
## 规格参数
工作质量 13.5t，铲斗容量 0.55m³。
## hostcode 差异对照
- `SSY100000402`：装 QSL9 231kW 发动机、液控多路阀 HVME700-000000-012（国四和新欧五，
  10寸触摸屏+空调控制盒）[原文](viking://resources/730/manuals/SY135C维修手册-2024版/chapters/07/chapter.md)，
  BOM 装配与参数标准值见配置档
  [SSY100000402](viking://resources/<ns>/ConfigSpec/SSY100000402/index.md)。
## 常见的故障现象及故障机理
- 发动机冒白烟：国四机型掺水燃烧机理优先，配置间差异见现象页的 Profile 子资源，详见
  [发动机冒白烟](viking://resources/<ns>/Symptom/动力与发动机/发动机冒白烟/发动机冒白烟.md)
## 关重件 Component 清单
- [发动机QSL9-231kW](viking://resources/<ns>/Component/发动机/发动机QSL9-231kW.md)
- [液控多路阀HVME700-000000-012](viking://resources/<ns>/Component/多路阀(主阀)/液控多路阀HVME700-000000-012.md)
## 故障代码清单
- P024 共轨压力低 → [共轨卸荷阀长开](viking://resources/<ns>/Fault/ControlFailure/共轨卸荷阀长开.md)
## 故障案例
（暂无——案例入库时对本节 append PATCH 逐条追加，不动其他节；建页可留空，空 ≠ 缺节。）

（说明：Device 页出处唯一字段是 raw_refs，不写通用 sources；config_specs 是派生投影
（元素为 ConfigSpec/<主体码>/index.md），事实源是配置档页自己的 device_refs，两向一致；
小节标题含 ≥2 个型号 = 一机型一页门拒。）
