---
id: bomcomp-25d949d14e0b30ef
title: 动臂油缸ZX245.3.1L
description: 动臂油缸大类下的规格页（手册/BOM 线形态），适用机型：SY26C、SY26U、SY135C。
class_name: 动臂油缸
object_name: 动臂油缸ZX245.3.1L
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
spec: 动臂油缸ZX245.3.1L
bom_path: 工作装置/动臂油缸
configuration_bindings: ["SY26C — SSY100000634", "SY26U — SSY100000634", "SY135C — 14543657"]
bom_evidence:
  - viking://resources/raw/bom/SY135C.md
applicable_models: [SY26C, SY26U, SY135C]
aliases: [动臂油缸]
sources:
  - viking://resources/raw/bom/SY135C.md
---
## 总成概览
BOM 清单登记的总成：动臂油缸，适用机型：SY26C、SY26U、SY135C
[原文](viking://resources/raw/bom/SY135C.md)。规格/型号：动臂油缸ZX245.3.1L。
## 工作机理
液压油通过油缸进油口推动活塞-活塞杆组件，将液压能转为工作装置起升/下降的机械能。
（源无原理但属通用工程件→用世界知识写原理并标 inferred，常态通道；只有
通用原理也给不出时才"待补充"；缺数值/型号/公差标准只挂 gap，不拖垮整节。
注意：本节是世界知识不是源文转述，**不配 [原文] 引用**；引文节级口径=同一
小节至多一条 [原文]（同节重复引擎会静默合并），跨节复引同一册合法。）
（说明：路径 Component/动臂油缸/动臂油缸ZX245.3.1L——大类段必须 ∈ 十九类词表；
关联故障从 Fault.affected_components 按需反查，不在本页保存故障清单；
bom_path/configuration_bindings/bom_evidence 仅手册/BOM 线写入。）
