---
id: profile-white-smoke-guosih-xinouwu
title: 发动机冒白烟·国四和新欧五配置档
description: 国四和新欧五（10寸触摸屏+空调控制盒）配置下发动机冒白烟的表现特征、可能机理与诊断顺序。
class_name: 动力与发动机
object_name: 发动机冒白烟·国四和新欧五配置档
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
parent_symptom: viking://resources/<ns>/Symptom/动力与发动机/发动机冒白烟/index.md
config_spec_uri: viking://resources/<ns>/ConfigSpec/SSY100000402/index.md
direct_component_uri: viking://resources/<ns>/Component/发动机/发动机QSL9-231kW.md
possible_faults:
  - viking://resources/<ns>/Fault/FluidFailure/燃油水分多.md
  - viking://resources/<ns>/Fault/ThermalFailure/缸垫渗漏冷却液.md
sources:
  - viking://resources/730/fault_mechanism/智能维修项目故障机理表-小挖/发动机冒白烟-小挖_动力.md
---
## 适用配置
主体码 SSY100000402 · 型号 SY135C · 现象发动机冒白烟；配置为国四和新欧五
（10寸触摸屏+空调控制盒），识别特征：仪表为10寸触摸屏且带空调控制盒
[原文](viking://resources/730/fault_mechanism/智能维修项目故障机理表-小挖/发动机冒白烟-小挖_动力.md)。
## 本配置下的表现特征
冷启动白烟持续时间长；伴燃油滤芯底部积水可见（放水面可查）。
## 与其他配置的差异
带EGR配置该现象更多指向EGR冷却内漏串入进气侧，本配置路径不同，故掺水燃烧占比更高
（同源引一次即可，后续内容靠 frontmatter sources 归源）。
## 可能失效机理
首选 燃油水分多 [燃油水分多](viking://resources/<ns>/Fault/FluidFailure/燃油水分多.md)：
本配置燃油过滤级数少，水分入燃烧室概率高；次选 缸垫渗漏冷却液
[缸垫渗漏冷却液](viking://resources/<ns>/Fault/ThermalFailure/缸垫渗漏冷却液.md)。
## 推荐诊断流程
按检查流程页《发动机冒白烟诊断流程》逐步执行
[发动机冒白烟诊断流程](viking://resources/<ns>/Procedure/inspection/发动机冒白烟诊断流程.md)，
本页不复述步骤；数值以配置档标准值表为准不复制。
## 引用判据
判据均出自机理表原文章节；溯源见上文行内引用与 frontmatter sources（禁锚点）。
## 来源
- 智能维修项目故障机理表-小挖·发动机冒白烟章（frontmatter sources 全列）。

（说明：住父现象目录（聚合页 index.md 同级）的 profiles/ 下；possible_faults 有序禁空且
候选机理可跨多个部件，归属由各 Fault.affected_components 表达；有主体码时 config_spec_uri 指
…/ConfigSpec/<主体码>/index.md；没有主体码时 device_uri 指已有
Device/<系列>/<型号>/index.md；config_spec_uri 与 device_uri 二者只能有一个，禁止为挂关系
新建 Device/ConfigSpec；禁线号；
**数值照写**——配置档正是
  记录具体配置的地方（2026-09-21 裁定：数值住 Component/ConfigSpec/Profile，
  Symptom 首页才禁数值）。）
