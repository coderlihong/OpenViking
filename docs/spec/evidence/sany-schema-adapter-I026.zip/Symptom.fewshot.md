---
id: symptom-white-smoke
title: 发动机冒白烟
description: 发动机运转过程中异常燃烧生成白烟的现象。
class_name: 动力与发动机
object_name: 发动机冒白烟
status: active
publication_state: published
validation_state: machine_validated
review_state: unreviewed
aliases: [冒白烟]
open_gaps:
  - gap_id: gap-white-smoke-oil-burn-config
    kind: missing_profile
    description: 烧机油导致蓝烟白烟混淆的配置差异未见手册证据
    evidence_hint: 国三共轨机型保养手册冒白烟章
sources:
  - viking://resources/730/fault_mechanism/智能维修项目故障机理表-小挖/发动机冒白烟-小挖_动力.md
---
## 现象定义
发动机运转过程中异常燃烧生成白烟[原文](viking://resources/730/fault_mechanism/智能维修项目故障机理表-小挖/发动机冒白烟-小挖_动力.md)。启动时冒白烟
多为水汽凝结（正常现象）；运行中持续冒白烟为异常。
## 典型观察特征
白烟由浓变稀后逐渐消失、热车后无异常→冷凝水；持续冒白烟伴掉速/限扭/憋车→燃烧掺水。
## 相似现象区分
区别于冒黑烟（不完全燃烧碳烟）
[发动机冒黑烟](viking://resources/<ns>/Symptom/动力与发动机/发动机冒黑烟/发动机冒黑烟.md)、
蓝烟（烧机油）。本页不展开机理——机理见各 Profile 的 possible_faults 与对应 Fault 页。
## 产品配置差异
带自动怠速功能的机型怠速工况下白烟观察窗口更短；有无EGR的配置白烟成因构成不同
（同源引一次即可，本页其余内容靠 frontmatter sources 归源）。
## Profile 索引
- viking://resources/<ns>/Symptom/动力与发动机/发动机冒白烟/profiles/国四和新欧五_10寸触摸屏空调控制盒.md
  —— 国四和新欧五（10寸触摸屏+空调控制盒）配置：掺水燃烧机理优先。
## 来源
- 智能维修项目故障机理表-小挖·发动机冒白烟章（frontmatter sources 全列）。

（说明：路径 Symptom/动力与发动机/发动机冒白烟/index.md——聚合页固定 index.md，
配置差异画像住同级 profiles/；related_fault/related_faults/device_applicability
已废止出现即 deny；正文禁线号与测量值；机型经 Profile 间接表达，本页不写机型。）
